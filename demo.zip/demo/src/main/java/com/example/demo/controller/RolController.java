package com.example.demo.controller;

import com.example.demo.entity.Rol;
import com.example.demo.service.RolService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping ("/api/rol")
public class RolController {
    private final RolService service;

    public RolController(RolService service){
        this.service = service;

    }
    @GetMapping("/Listar")
    public List<Rol> listar(){
        return service.Listar();
    }
}
