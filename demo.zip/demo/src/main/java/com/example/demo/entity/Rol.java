package com.example.demo.entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;


@Entity
@Table(name = "Rol")
@Getter
@Setter
public class Rol {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name ="idRol")
    private int idRol;

    @Column(name ="descripcion")
    private String descripcion;

    @Column(name ="estado")
    private String estado;

}
