package com.example.demo.service;

import com.example.demo.entity.Rol;
import com.example.demo.repository.RolRepository;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class RolService {
    private final RolRepository repository;
    public RolService(RolRepository repository){
        this.repository = repository;
    }
    public List<Rol> Listar(){
        return repository.findAll();
    }

}
